CREATE PROCEDURE insertNewUser(IN uName  VARCHAR(35), IN uLogin VARCHAR(35), IN uPass VARCHAR(15), IN uMail VARCHAR(20),
                               IN uPhone VARCHAR(15), IN uStatus VARCHAR(20))
  BEGIN 
 INSERT INTO ROOMUSER ( U_NAME, U_LOGIN, U_PASS, U_MAIL, U_PHONE, STATUS )
           VALUES ( uName, uLogin, uPass, uMail, uPhone, uStatus);
COMMIT; 
END;

